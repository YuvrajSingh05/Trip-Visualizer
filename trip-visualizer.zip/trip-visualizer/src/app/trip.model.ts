
export interface Trip {
    start: string;
    end: string;
    level: number;
    continued: boolean;
    repeated: boolean;
  }