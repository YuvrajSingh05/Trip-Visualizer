import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: '<app-trip-visualizer></app-trip-visualizer>',
})
export class AppComponent {}