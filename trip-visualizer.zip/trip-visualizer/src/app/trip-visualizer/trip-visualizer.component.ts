import { Component } from '@angular/core';
import { Trip } from '../trip.model';

@Component({
  selector: 'app-trip-visualizer',
  templateUrl: './trip-visualizer.component.html',
  styleUrls: ['./trip-visualizer.component.scss']
})
export class TripVisualizerComponent {
  start = '';
  end = '';
  trips: Trip[] = [];
  error = '';

  addTrip() {
    this.error = '';
    if (!this.start || !this.end) {
      this.error = 'Both Start and End points are required.';
      return;
    }
  
    const startShort = this.start.slice(0, 3).toUpperCase();
    const endShort = this.end.slice(0, 3).toUpperCase();
    const newTrip: Trip = {
      start: startShort,
      end: endShort,
      level: 1,
      continued: false,
      repeated: false
    };
  
    const lastTrip = this.trips[this.trips.length - 1];
  
    if (lastTrip) {
      if (lastTrip.end === newTrip.start) {
        newTrip.continued = true;
      } else if (lastTrip.start === newTrip.start && lastTrip.end === newTrip.end) {
        newTrip.level = 2;
        newTrip.repeated = true;
      }
    }
  
    this.trips.push(newTrip);
    this.start = this.end = '';
  }
  
}
