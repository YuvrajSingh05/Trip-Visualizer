import { Component } from '@angular/core';
import { Trip } from './models/trip.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  startPoint = '';
  endPoint = '';
  trips: Trip[] = [];

  addTrip() {
    if (!this.startPoint || !this.endPoint) return;

    const lastTrip = this.trips[this.trips.length - 1];
    const newTrip: Trip = {
      start: this.startPoint,
      end: this.endPoint,
      level: 1,
      continued: false,
      sameLocation: false
    };

    if (lastTrip) {
      if (lastTrip.end.toLowerCase() === newTrip.start.toLowerCase()) {
        newTrip.continued = true;
      } else {
        newTrip.continued = false;
      }

      if (
        lastTrip.start.toLowerCase() === newTrip.start.toLowerCase() &&
        lastTrip.end.toLowerCase() === newTrip.end.toLowerCase()
      ) {
        newTrip.level = 2;
        newTrip.sameLocation = true;
      }
    }

    this.trips.push(newTrip);
    this.startPoint = '';
    this.endPoint = '';
  }
}