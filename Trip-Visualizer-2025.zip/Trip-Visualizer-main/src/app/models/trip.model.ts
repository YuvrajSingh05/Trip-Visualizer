export interface Trip {
  id: number;
  startPoint: string;
  endPoint: string;
}

export interface TripWithLevel extends Trip {
  level: number;
  isContinued: boolean;
} 