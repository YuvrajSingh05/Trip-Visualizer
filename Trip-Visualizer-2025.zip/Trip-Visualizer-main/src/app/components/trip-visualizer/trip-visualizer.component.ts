import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Trip, TripWithLevel } from '../../models/trip.model';

@Component({
  selector: 'app-trip-visualizer',
  templateUrl: './trip-visualizer.component.html',
  styleUrls: ['./trip-visualizer.component.scss']
})
export class TripVisualizerComponent {
  tripForm: FormGroup;
  trips: TripWithLevel[] = [];
  private tripCounter = 0;

  constructor(private fb: FormBuilder) {
    this.tripForm = this.fb.group({
      startPoint: ['', Validators.required],
      endPoint: ['', Validators.required]
    });
  }

  addTrip(): void {
    if (this.tripForm.valid) {
      const newTrip: Trip = {
        id: ++this.tripCounter,
        startPoint: this.tripForm.value.startPoint.trim(),
        endPoint: this.tripForm.value.endPoint.trim()
      };

      const tripWithLevel = this.calculateTripLevel(newTrip);
      this.trips.push(tripWithLevel);
      this.tripForm.reset();
    }
  }

  private calculateTripLevel(newTrip: Trip): TripWithLevel {
    let level = 1;
    let isContinued = false;

    if (this.trips.length > 0) {
      const lastTrip = this.trips[this.trips.length - 1];

      if (lastTrip.endPoint.toLowerCase() === newTrip.startPoint.toLowerCase()) {
        isContinued = true;
      }

      if (
        lastTrip.startPoint.toLowerCase() === newTrip.startPoint.toLowerCase() &&
        lastTrip.endPoint.toLowerCase() === newTrip.endPoint.toLowerCase()
      ) {
        level = 2;
      }
    }

    return {
      ...newTrip,
      level,
      isContinued
    };
  }

  getShortLocation(location: string): string {
    return location.slice(0, 3).toUpperCase();
  }
}
